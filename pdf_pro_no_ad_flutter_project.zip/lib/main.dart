import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'services/file_manager_service.dart';
import 'services/permission_service.dart';
import 'services/preferences_service.dart';
import 'widgets/bottom_nav_bar.dart';
import 'widgets/privacy_dialog.dart';
import 'widgets/speed_dial_fab.dart';
import 'screens/home_screen.dart';
import 'screens/all_documents_screen.dart';
import 'screens/tools_screen.dart';
import 'screens/me_screen.dart';
import 'screens/image_to_pdf_screen.dart';
import 'screens/camera_scanner_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
      systemNavigationBarColor: Color(0xFF000000),
      systemNavigationBarIconBrightness: Brightness.light,
    ),
  );

  final prefs = PreferencesService();
  await prefs.init();

  final fileManager = FileManagerService();

  runApp(PdfProApp(prefs: prefs, fileManager: fileManager));
}

class PdfProApp extends StatefulWidget {
  final PreferencesService prefs;
  final FileManagerService fileManager;

  const PdfProApp({
    super.key,
    required this.prefs,
    required this.fileManager,
  });

  @override
  State<PdfProApp> createState() => _PdfProAppState();
}

class _PdfProAppState extends State<PdfProApp> {
  late bool _isDarkMode;

  @override
  void initState() {
    super.initState();
    _isDarkMode = widget.prefs.isDarkMode;
  }

  void _toggleTheme() {
    setState(() {
      _isDarkMode = !_isDarkMode;
      widget.prefs.setDarkMode(_isDarkMode);
    });
  }

  @override
  Widget build(BuildContext context) {
    final darkTheme = ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      scaffoldBackgroundColor: const Color(0xFF000000), // AMOLED pitch-black
      colorScheme: const ColorScheme.dark(
        primary: Color(0xFFE50914),
        secondary: Color(0xFF8B5CF6),
        surface: Color(0xFF101010),
        onSurface: Colors.white,
      ),
    );

    return MaterialApp(
      title: 'PDF Pro No Ad',
      debugShowCheckedModeBanner: false,
      theme: darkTheme,
      home: RootNavigationContainer(
        prefs: widget.prefs,
        fileManager: widget.fileManager,
        isDarkMode: _isDarkMode,
        onToggleTheme: _toggleTheme,
      ),
    );
  }
}