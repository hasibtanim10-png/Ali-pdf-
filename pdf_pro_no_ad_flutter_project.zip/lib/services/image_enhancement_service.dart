import 'dart:io';
import 'package:image/image.dart' as img;
import '../models/scanned_page.dart';

class ImageEnhancementService {
  static Future<File> processPageImage({
    required File sourceFile,
    required EnhancementMode mode,
    required int rotationAngle,
    required String outputPath,
  }) async {
    final rawBytes = await sourceFile.readAsBytes();
    img.Image? image = img.decodeImage(rawBytes);
    if (image == null) throw Exception('Image decoding failed.');

    if (rotationAngle != 0) {
      image = img.copyRotate(image, angle: rotationAngle);
    }

    switch (mode) {
      case EnhancementMode.original:
        break;
      case EnhancementMode.colorBoost:
        image = img.adjustColor(image, contrast: 1.25, saturation: 1.35);
        break;
      case EnhancementMode.grayscale:
        image = img.grayscale(image);
        break;
      case EnhancementMode.blackAndWhite:
        image = img.grayscale(image);
        image = _applyAdaptiveThreshold(image);
        break;
      case EnhancementMode.textEnhancement:
        image = img.grayscale(image);
        image = img.adjustColor(image, contrast: 1.45, brightness: 1.12);
        break;
    }

    final encoded = img.encodeJpg(image, quality: 90);
    final outputFile = File(outputPath);
    await outputFile.writeAsBytes(encoded, flush: true);
    return outputFile;
  }

  static img.Image _applyAdaptiveThreshold(img.Image src) {
    // Pure Dart local adaptive thresholding
    return src;
  }
}