import 'package:flutter_test/flutter_test.dart';
import 'package:flutter/material.dart';
import 'package:pdf_pro_no_ad/widgets/bottom_nav_bar.dart';

void main() {
  testWidgets('BottomNavBar renders exact 4 tabs: Home, All Documents, Tools, Me', (WidgetTester tester) async {
    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(
          bottomNavigationBar: BottomNavBar(
            currentIndex: 0,
            onTap: (_) {},
          ),
        ),
      ),
    );

    expect(find.text('Home'), findsOneWidget);
    expect(find.text('All Documents'), findsOneWidget);
    expect(find.text('Tools'), findsOneWidget);
    expect(find.text('Me'), findsOneWidget);
  });
}